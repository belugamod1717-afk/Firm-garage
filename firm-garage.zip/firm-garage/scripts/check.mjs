// Static validation (no dependencies): every local link/src exists, every inline & local script parses,
// each page has a title, and no real-looking secrets are in front-end code. "build" = this check (site is static).
import fs from "node:fs"; import path from "node:path";
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), ".."); let errors = 0, pages = 0;
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.name.startsWith(".") || e.name === "node_modules" ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const files = walk(root), bad = m => { errors++; console.error("✗ " + m); };
const AsyncFn = Object.getPrototypeOf(async function () {}).constructor;
for (const f of files.filter(f => f.endsWith(".html"))) {
  pages++; const rel = path.relative(root, f), s = fs.readFileSync(f, "utf8");
  if (!/<title>[^<]{3,}/.test(s)) bad(rel + ": missing <title>");
  for (const m of s.matchAll(/(?:href|src)="([^"#?]+)(?:[?#][^"]*)?"/g)) {
    const u = m[1]; if (/^(https?:|mailto:|tel:|data:|javascript:)/.test(u) || u.includes("${") || u.startsWith("'")) continue;
    const p = u.startsWith("/") ? path.join(root, u) : path.join(path.dirname(f), u);
    if (!fs.existsSync(p) && !fs.existsSync(p + ".html")) bad(`${rel}: broken reference ${u}`);
  }
  for (const m of s.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)) {
    if (/src=/.test(m[1]) || !m[2].trim() || /type="(?!module)[^"]*json/.test(m[1])) continue;
    try { new AsyncFn(m[2].replace(/^\s*import\s.*$/gm, "")); } catch (e) { bad(`${rel}: inline script syntax error: ${e.message}`); }
  }
}
for (const f of files.filter(f => f.endsWith(".js"))) { try { new AsyncFn(fs.readFileSync(f, "utf8").replace(/^\s*import\s.*$/gm, "").replace(/^\s*export\s+/gm, "")); } catch (e) { bad(path.relative(root, f) + ": " + e.message); } }
const secret = /service_role|sk_live|-----BEGIN|AKIA[0-9A-Z]{12}/;
for (const f of files.filter(f => /\.(html|js|json)$/.test(f) && !f.endsWith("check.mjs"))) if (secret.test(fs.readFileSync(f, "utf8"))) bad("possible secret in " + path.relative(root, f));
console.log(`${pages} pages checked, ${errors} problem(s).`); process.exit(errors ? 1 : 0);
