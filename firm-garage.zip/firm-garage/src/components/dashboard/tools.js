/* Dashboard trading tools: Risk/Reward + Margin, Drawdown tracker, Payout calculator.
   Everything runs in the browser; no inputs are sent or stored. Mounts into #toolsRoot (dashboard.html). */
(function () {
  var root = document.getElementById("toolsRoot"); if (!root) return;
  root.innerHTML =
'<div class="tabs" role="tablist"><button class="tab" role="tab" data-t="rr" aria-selected="true">Risk &middot; Reward &middot; Margin</button><button class="tab" role="tab" data-t="dd" aria-selected="false">Drawdown tracker</button><button class="tab" role="tab" data-t="po" aria-selected="false">Payout calculator</button></div>' +
'<section id="t-rr" class="wrap"><div class="tp"><h2>Trade setup</h2><div class="grid2">' +
F("rrBal","Account balance ($)",100000) + F("rrRisk","Risk per trade (%)",0.5,"step=0.1") + S("rrDir","Direction",[["long","Long"],["short","Short"]]) + F("rrLev","Leverage (1:x)",30) +
F("rrEntry","Entry price",1.085,"step=any") + F("rrStop","Stop-loss price",1.082,"step=any") + F("rrTp","Take-profit price",1.091,"step=any") + F("rrCs","Units per 1.0 lot",100000) + F("rrWin","Your win rate (%)",45) +
'</div><p class="note">Defaults model EUR/USD (1 lot = 100,000 units, USD-quoted). For futures use the contract multiplier (e.g. 50 for ES). Cross-pairs need conversion to your account currency.</p></div><div class="tp"><h2>Result</h2><div class="res" id="rrOut"></div></div></section>' +
'<section id="t-dd" class="wrap" hidden><div class="tp"><h2>Account &amp; rules</h2><div class="grid2">' +
F("ddStart","Starting balance ($)",100000) + F("ddEq","Current equity ($)",103200) + F("ddPeak","Highest equity reached ($)",104500) + F("ddSod","Start-of-day balance ($)",102800) +
F("ddMax","Max drawdown (%)",10,"step=0.5") + F("ddDay","Max daily loss (%)",5,"step=0.5") + S("ddType","Drawdown type",[["static","Static (from start)"],["trail","Trailing (from peak)"]],"trail") + F("ddTgt","Profit target (%)",8,"step=0.5") +
'</div><label class="chk"><input type="checkbox" id="ddLock" checked> Trailing floor locks at starting balance</label><p class="note">Firms differ (balance vs equity, intraday vs end-of-day). Enter figures exactly as your firm measures them.</p></div><div class="tp"><h2>Status</h2><div class="res" id="ddOut"></div></div></section>' +
'<section id="t-po" class="wrap" hidden><div class="tp"><h2>Payout inputs</h2><div class="grid2">' +
F("poProfit","Total profit ($)",6000) + F("poSplit","Profit split (%)",80) + F("poBest","Best single-day profit ($)",1500) + F("poCap","Consistency cap (best day ≤ %)",30) +
F("poDays","Trading days completed",8) + F("poMinD","Minimum trading days",5) + F("poMinP","Minimum payout ($)",100) + F("poFee","Challenge / eval fee paid ($)",540) +
'</div><p class="note">Set the consistency cap to 0 if your firm has none. Rules vary — confirm with the firm.</p></div><div class="tp"><h2>Estimate</h2><div class="res" id="poOut"></div></div></section>' +
'<p class="note">Educational estimates only — not financial advice. Trading is high-risk. <a href="/risk-disclosure.html" target="_blank" rel="noopener" style="color:var(--accent)">Risk disclosure</a>.</p>';

  function F(id, l, v, x) { return '<div class="f"><label for="' + id + '">' + l + '</label><input id="' + id + '" type="number" value="' + v + '" ' + (x ? x.replace("=", '="') + '"' : "") + "></div>"; }
  function S(id, l, o, sel) { return '<div class="f"><label for="' + id + '">' + l + '</label><select id="' + id + '">' + o.map(function (x) { return '<option value="' + x[0] + '"' + (x[0] === sel ? " selected" : "") + ">" + x[1] + "</option>"; }).join("") + "</select></div>"; }
  var $ = function (i) { return document.getElementById(i); }, n = function (i) { return parseFloat($(i).value) || 0; };
  var usd = function (v) { return (v < 0 ? "-" : "") + "$" + Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var pct = function (v) { return v.toFixed(2) + "%"; };
  var K = function (l, v, c, full) { return '<div class="k' + (full ? " full" : "") + '"><small>' + l + '</small><b class="' + (c || "") + '">' + v + "</b></div>"; };
  var bar = function (v, c) { return '<div class="bar"><i style="width:' + v + "%;background:var(--" + c + ')"></i></div>'; };

  root.querySelectorAll(".tab").forEach(function (b) { b.onclick = function () {
    root.querySelectorAll(".tab").forEach(function (x) { x.setAttribute("aria-selected", x === b); });
    ["rr", "dd", "po"].forEach(function (t) { $("t-" + t).hidden = t !== b.dataset.t; }); }; });

  function rr() {
    var bal = n("rrBal"), rp = n("rrRisk"), e = n("rrEntry"), s = n("rrStop"), t = n("rrTp"), lev = Math.max(1, n("rrLev")), cs = n("rrCs"), w = n("rrWin") / 100, long = $("rrDir").value === "long";
    var risk = bal * rp / 100, sd = long ? e - s : s - e, td = long ? t - e : e - t;
    if (sd <= 0 || td <= 0 || cs <= 0 || e <= 0) { $("rrOut").innerHTML = K("Check inputs", "Stop-loss must be on the losing side of entry and take-profit on the winning side.", "bad", true); return; }
    var lots = risk / (sd * cs), units = lots * cs, notional = units * e, margin = notional / lev, reward = units * td, R = td / sd, be = 100 / (1 + R), ev = w * reward - (1 - w) * risk;
    $("rrOut").innerHTML = K("Risk : Reward", "1 : " + R.toFixed(2), R >= 2 ? "ok" : R >= 1 ? "warn" : "bad") + K("Break-even win rate", pct(be), w * 100 >= be ? "ok" : "bad") +
      K("Position size", lots.toFixed(2) + " lots") + K("Units", Math.round(units).toLocaleString()) + K("Amount at risk", usd(risk), "bad") + K("Potential reward", usd(reward), "ok") +
      K("Notional exposure", usd(notional)) + K("Margin required", usd(margin), margin > bal ? "bad" : "") + K("Margin used", pct(margin / bal * 100), margin / bal > 0.5 ? "warn" : "") + K("Free margin", usd(bal - margin)) +
      K("Expected value per trade (at your win rate)", usd(ev), ev >= 0 ? "ok" : "bad", true);
  }
  function dd() {
    var S0 = n("ddStart"), E = n("ddEq"), P = Math.max(n("ddPeak"), E), sod = n("ddSod"), mx = n("ddMax") / 100 * S0, dl = n("ddDay") / 100 * S0, tg = S0 * (1 + n("ddTgt") / 100), trail = $("ddType").value === "trail";
    var floor = trail ? P - mx : S0 - mx; if (trail && $("ddLock").checked) floor = Math.min(floor, S0);
    var dfloor = sod - dl, buf = E - floor, dbuf = E - dfloor, cl = function (v) { return Math.max(0, Math.min(100, v)); };
    var used = cl((1 - buf / mx) * 100), dused = cl((1 - dbuf / dl) * 100), prog = cl((E - S0) / (tg - S0) * 100);
    var breached = E <= floor || E <= dfloor, close = !breached && (buf < mx * 0.25 || dbuf < dl * 0.25);
    $("ddOut").innerHTML = '<div class="k full"><small>Status</small><b class="' + (breached ? "bad" : close ? "warn" : "ok") + '">' + (breached ? "BREACHED" : close ? "DANGER ZONE" : "SAFE") + "</b></div>" +
      K("Max-drawdown floor", usd(floor)) + K("Daily-loss floor", usd(dfloor)) + K("Room to max DD", usd(buf), buf <= 0 ? "bad" : "") + K("Room today", usd(dbuf), dbuf <= 0 ? "bad" : "") +
      '<div class="k full"><small>Max drawdown used &middot; ' + used.toFixed(0) + "%</small>" + bar(used, used > 75 ? "bad" : used > 50 ? "gold" : "ok") + '</div><div class="k full"><small>Daily loss used &middot; ' + dused.toFixed(0) + "%</small>" + bar(dused, dused > 75 ? "bad" : dused > 50 ? "gold" : "ok") + "</div>" +
      '<div class="k full"><small>Profit target ' + usd(tg) + " &middot; " + prog.toFixed(0) + "%</small>" + bar(prog, "accent") + "</div>" + K("Hard stop level (tighter of both)", usd(Math.max(floor, dfloor)), "", true);
  }
  function po() {
    var p = n("poProfit"), sp = n("poSplit") / 100, b = n("poBest"), cap = n("poCap"), d = n("poDays"), md = n("poMinD"), mp = n("poMinP"), fee = n("poFee");
    var mine = Math.max(0, p) * sp, firm = Math.max(0, p) - mine, share = p > 0 ? b / p * 100 : 0, consOK = cap === 0 || share <= cap, need = cap > 0 ? b / (cap / 100) : 0, daysOK = d >= md, minOK = mine >= mp, elig = consOK && daysOK && minOK && p > 0;
    $("poOut").innerHTML = '<div class="k full"><small>Eligibility (as entered)</small><b class="' + (elig ? "ok" : "bad") + '">' + (elig ? "ELIGIBLE" : "NOT YET") + "</b></div>" +
      K("Your payout", usd(mine), "ok") + K("Firm share", usd(firm)) + K("Best day / total", share.toFixed(1) + "%", consOK ? "ok" : "bad") + K("Trading days", d + " / " + md, daysOK ? "ok" : "bad") +
      K("Minimum payout met", minOK ? "Yes" : "No", minOK ? "ok" : "bad") + K("Fee recovered?", mine >= fee ? "Yes" : "Not yet — " + usd(fee - mine) + " short", mine >= fee ? "ok" : "warn") +
      (consOK ? "" : K("Total profit needed for consistency", usd(need) + " (+" + usd(Math.max(0, need - p)) + ")", "warn", true)) + K("Net after fee", usd(mine - fee), mine - fee >= 0 ? "ok" : "bad", true);
  }
  function wire(ids, f) { ids.forEach(function (i) { $(i).addEventListener("input", f); }); f(); }
  wire(["rrBal", "rrRisk", "rrDir", "rrLev", "rrEntry", "rrStop", "rrTp", "rrCs", "rrWin"], rr);
  wire(["ddStart", "ddEq", "ddPeak", "ddSod", "ddMax", "ddDay", "ddType", "ddTgt", "ddLock"], dd);
  wire(["poProfit", "poSplit", "poBest", "poCap", "poDays", "poMinD", "poMinP", "poFee"], po);
})();
