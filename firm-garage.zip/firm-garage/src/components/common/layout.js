/* Public layout: header, footer, privacy notice and Tawk.to chat. Reads window.FG (src/config/siteConfig.js).
   Include on PUBLIC pages only:  <script src="/src/config/siteConfig.js"></script><script src="/src/components/common/layout.js"></script>
   Place right after <body> so the header exists before page scripts run. */
(function () {
  var C = window.FG || {}, THEME_KEY = "Firm Garage-theme";
  try { document.documentElement.setAttribute("data-theme", localStorage.getItem(THEME_KEY) || "dark"); } catch (e) { document.documentElement.setAttribute("data-theme", "dark"); }
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var file = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  var map = { "index.html": "home", "": "home", "firms.html": "compare", "firm.html": "compare", "about.html": "about", "contact.html": "contact" };
  var cur = map[file] || "";
  var nm = esc(C.name || "Firm Garage"), parts = nm.split(" ");
  var brand = C.logoImage ? '<img src="' + esc(C.logoImage) + '" alt="">' : '<span class="fg-mark">' + esc(C.abbr || "FG") + "</span>";
  var link = function (href, label, key) { return '<a href="' + href + '"' + (cur === key ? ' aria-current="page"' : "") + ">" + label + "</a>"; };
  var header =
    '<header class="fg-header" id="fgHeader"><div class="fg-wrap fg-header-in">' +
    '<a class="fg-logo" id="brandLogo" href="/index.html">' + brand + "<span>" + parts[0] + (parts[1] ? " <b>" + parts.slice(1).join(" ") + "</b>" : "") + "</span></a>" +
    '<nav class="fg-nav" id="fgNav" aria-label="Main">' + link("/index.html", "Home", "home") + link("/firms.html", "Compare Firms", "compare") + link("/about.html", "About Us", "about") +
    '<a class="fg-contact-m" href="/contact.html" style="display:none">Contact Us</a><a class="fg-signin-m" href="/auth.html?mode=signin">Sign In</a></nav>' +
    '<div class="fg-actions"><a class="fg-btn fg-contact" href="/contact.html">Contact Us</a>' +
    '<button class="fg-icon-btn" id="themeToggle" type="button" title="Toggle theme" aria-label="Toggle theme"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 3v18" /><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/></svg></button>' +
    '<div id="feAuthArea" style="display:flex;align-items:center;gap:8px"><a class="fg-btn" href="/auth.html?mode=signin">Sign In</a><a class="fg-btn solid" href="/auth.html?mode=signup">Sign Up</a></div>' +
    '<button class="fg-icon-btn fg-burger" id="fgBurger" type="button" aria-label="Menu" aria-expanded="false" aria-controls="fgNav"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>' +
    "</div></div></header>";
  document.body.insertAdjacentHTML("afterbegin", header);
  var h = document.getElementById("fgHeader");
  var mc = h.querySelector(".fg-contact-m"); if (mc) mc.style.display = "";
  document.getElementById("fgBurger").addEventListener("click", function () { var o = h.classList.toggle("open"); this.setAttribute("aria-expanded", o); });
  var tt = document.getElementById("themeToggle");
  tt.addEventListener("click", function () { var t = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark"; document.documentElement.setAttribute("data-theme", t); try { localStorage.setItem(THEME_KEY, t); } catch (e) {} });

  function footer() {
    var L = C.legal || {}, S = C.social || {}, K = C.contact || {};
    var labels = { x: "X (Twitter)", instagram: "Instagram", youtube: "YouTube", discord: "Discord", telegram: "Telegram", linkedin: "LinkedIn", facebook: "Facebook" };
    var soc = Object.keys(labels).filter(function (k) { return S[k]; }).map(function (k) { return '<a href="' + esc(S[k]) + '" target="_blank" rel="noopener noreferrer">' + labels[k] + "</a>"; }).join("");
    var mail = K.email ? '<a href="mailto:' + esc(K.email) + '">' + esc(K.email) + "</a>" : "";
    var f = '<footer class="fg-footer"><div class="fg-wrap"><div class="fg-foot-grid"><div><a class="fg-logo" href="/index.html">' + brand + "<span>" + nm + "</span></a>" +
      '<p style="color:var(--text-dim);font-size:14px;margin-top:12px;max-width:300px">' + esc(C.tagline || "") + "</p></div>" +
      '<div><h4>Platform</h4><a href="/index.html">Home</a><a href="/firms.html">Compare Firms</a><a href="/about.html">About Us</a><a href="/contact.html">Contact Us</a><a href="/blog.html">Blog</a><a href="/faq.html">FAQ</a></div>' +
      "<div><h4>Legal</h4><a href=\"" + (L.privacy || "#") + '">Privacy Policy</a><a href="' + (L.terms || "#") + '">Terms of Service</a><a href="' + (L.risk || "#") + '">Risk Disclosure</a><a href="' + (L.affiliate || "#") + '">Affiliate Disclosure</a></div>' +
      (soc || mail ? "<div><h4>Connect</h4>" + soc + mail + "</div>" : "<div><h4>Connect</h4><a href=\"/contact.html\">Contact form</a></div>") +
      '</div><div class="fg-foot-note">© ' + new Date().getFullYear() + " " + nm + ". Independent research platform — not a broker or investment adviser. Trading involves substantial risk of loss. Always verify rules with the firm before purchasing.</div></div></footer>";
    var slot = document.getElementById("fgFooter");
    if (slot) slot.outerHTML = f; else document.body.insertAdjacentHTML("beforeend", f);
  }
  function notice() {
    try { if (localStorage.getItem("fg-consent")) return; } catch (e) { return; }
    var d = document.createElement("div"); d.id = "fgConsent"; d.setAttribute("role", "dialog"); d.setAttribute("aria-label", "Privacy notice");
    d.innerHTML = '<span>We use essential storage only (login session and theme). See our <a href="' + esc((C.legal || {}).privacy || "/privacy.html") + '">Privacy Policy</a>.</span><button type="button">Got it</button>';
    d.querySelector("button").onclick = function () { try { localStorage.setItem("fg-consent", "1"); } catch (e) {} d.remove(); };
    document.body.appendChild(d);
  }
  function chat() { // Tawk.to — loads once, only when BOTH ids are configured.
    var T = C.tawk || {}; if (!T.propertyId || !T.widgetId || window.__fgTawk) return; window.__fgTawk = true;
    window.Tawk_API = window.Tawk_API || {}; window.Tawk_LoadStart = new Date();
    var s = document.createElement("script"); s.async = true; s.src = "https://embed.tawk.to/" + encodeURIComponent(T.propertyId) + "/" + encodeURIComponent(T.widgetId);
    s.charset = "UTF-8"; s.setAttribute("crossorigin", "*"); document.head.appendChild(s);
  }
  function init() { footer(); notice(); chat(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
