/* ===========================================================================
   Firm Garage — SINGLE place to edit company details.
   Classic script (not a module) so every page can read window.FG before it paints.
   Leave a value as "" to hide it. Nothing here is a secret — never put private keys in this file.
   =========================================================================== */
window.FG = Object.freeze({
  name: "Firm Garage",
  abbr: "FG",
  tagline: "Compare prop trading firms with confidence.",
  siteUrl: "https://firm-garage-two.vercel.app",
  logoImage: "",                       // e.g. "/assets/images/logo.png". Empty = text "FG" mark.
  favicon: "/assets/images/logo.png",  // NOTE: <link rel="icon"> tags in each HTML <head> must be edited too if you change this.
  theme: { accent: "#3b82f6", navy: "#050b1a" }, // informational; the live colours are in src/styles/variables.css

  contact: {
    email: "",          // general contact email
    supportEmail: "",
    businessEmail: "",
    phone: "",
    address: "",
    // Contact form delivery. Leave empty and the form tells visitors it is not connected.
    // Example (Formspree): "https://formspree.io/f/xxxxxxx"  — see README "Contact form".
    formEndpoint: ""
  },
  social: { x: "", instagram: "", youtube: "", discord: "", telegram: "", linkedin: "", facebook: "" },

  // Tawk.to live chat — find both IDs in Tawk.to → Administration → Channels → Chat Widget → "Direct Chat Link":
  //   https://tawk.to/chat/<PROPERTY_ID>/<WIDGET_ID>
  // If either is empty the widget is simply not loaded.
  tawk: { propertyId: "", widgetId: "" },

  legal: {
    privacy: "/privacy.html", terms: "/terms.html",
    risk: "/risk-disclosure.html", affiliate: "/affiliate-disclosure.html"
  }
});
